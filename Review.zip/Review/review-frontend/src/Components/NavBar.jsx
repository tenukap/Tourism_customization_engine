import { useNavigate, useLocation } from 'react-router-dom'

export default function NavBar() {
    const navigate = useNavigate()
    const location = useLocation()

    return (
        <nav className="navbar">
            <div className="navbar-logo" onClick={() => window.location.href = 'http://localhost:5173'}>
                Travel<span>Us</span>
            </div>
            <div className="navbar-links">
                <button className={`nav-link ${location.pathname === '/' ? 'active' : ''}`} onClick={() => navigate('/')}>Reviews</button>
                <button className={`nav-link ${location.pathname === '/admin' ? 'active' : ''}`} onClick={() => navigate('/admin')}>Admin</button>
                <button className="nav-link" onClick={() => window.location.href = 'http://localhost:3000'}>Packages</button>
                <button className="nav-btn" onClick={() => window.location.href = 'http://localhost:5173'}>← Home</button>
            </div>
        </nav>
    )
}