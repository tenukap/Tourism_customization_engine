import { BrowserRouter, Routes, Route } from 'react-router-dom'
import ReviewPage   from './Pages/ReviewPage'
import AdminPage    from './Pages/AdminPage'

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/"      element={<ReviewPage />} />
        <Route path="/admin" element={<AdminPage />} />
      </Routes>
    </BrowserRouter>
  )
}

export default App
