import { useState, useEffect } from 'react'
import NavBar from '../Components/NavBar'
import { submitReview, getAllReviews, getStarRating } from '../Services/reviewService'

const AVATARS  = ['🧳','✈️','🌍','🏖','🗺','🏔','🌴','🚢']
const NAMES    = ['Alex T.','Sam K.','Jordan M.','Riley P.','Morgan S.','Casey B.','Drew L.','Quinn R.']
const COMMENTS = [
    'Amazing experience! Highly recommend.',
    'Wonderful trip, great memories.',
    'Everything was well organised.',
    'Beautiful destinations and great guides.',
    'Will definitely travel again with TravelUs!',
    'Exceeded all my expectations.',
    'Smooth booking and fantastic service.',
    'Perfect holiday from start to finish.'
]

export default function ReviewPage() {
    const [reviews,        setReviews]        = useState([])
    const [selectedRating, setSelectedRating] = useState(0)
    const [hoveredRating,  setHoveredRating]  = useState(0)
    const [starDisplay,    setStarDisplay]    = useState('')
    const [loading,        setLoading]        = useState(true)
    const [submitting,     setSubmitting]     = useState(false)
    const [success,        setSuccess]        = useState('')
    const [error,          setError]          = useState('')

    useEffect(() => { fetchReviews() }, [])

    const fetchReviews = async () => {
        setLoading(true)
        try {
            const data = await getAllReviews()
            setReviews(data)
        } catch {
            setError('Cannot connect to backend. Make sure Spring Boot is running on port 8082.')
        } finally { setLoading(false) }
    }

    const handleStarHover = async (rating) => {
        setHoveredRating(rating)
        try {
            const data = await getStarRating(rating)
            setStarDisplay(data.stars)
        } catch {}
    }

    const handleSubmit = async (e) => {
        e.preventDefault()
        if (selectedRating === 0) { setError('Please select a star rating.'); return }
        setSubmitting(true); setError(''); setSuccess('')
        try {
            await submitReview(selectedRating)
            setSuccess(`Thank you! Your ${selectedRating}-star review has been submitted.`)
            setSelectedRating(0); setStarDisplay('')
            fetchReviews()
        } catch {
            setError('Failed to submit review. Please try again.')
        } finally { setSubmitting(false) }
    }

    const avgRating = reviews.length > 0
        ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
        : 0

    const starCounts = [5,4,3,2,1].map(star => ({
        star,
        count: reviews.filter(r => r.rating === star).length,
        percent: reviews.length > 0
            ? Math.round((reviews.filter(r => r.rating === star).length / reviews.length) * 100)
            : 0
    }))

    const activeRating = hoveredRating || selectedRating

    return (
        <div>
            <NavBar />

            {/* Hero */}
            <div className="hero">
                <img src="https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=1600" alt="hero" />
                <div className="hero-overlay">
                    <h1>Travel Reviews</h1>
                    <p>Share your experience and help other travellers</p>
                    <button className="btn-outline" onClick={() => document.getElementById('review-section').scrollIntoView({ behavior: 'smooth' })}>
                        Write a Review ↓
                    </button>
                </div>
            </div>

            {/* Content */}
            <div className="section" id="review-section">
                <div className="container">
                    <div className="text-center" style={{marginBottom: 48}}>
                        <h2 className="section-title">What Travellers Say</h2>
                        <p className="section-sub">Rate your travel experience with TravelUs</p>
                    </div>

                    <div className="grid-1-2">
                        {/* Left — Submit + Overall */}
                        <div>
                            <div className="card" style={{marginBottom: 24}}>
                                <h3 style={{fontSize: 22, fontWeight: 700, marginBottom: 24}}>Rate Your Experience</h3>

                                {success && <div className="alert-success">✅ {success}</div>}
                                {error   && <div className="alert-error">⚠ {error}</div>}

                                <form onSubmit={handleSubmit}>
                                    <p style={{fontSize: 14, fontWeight: 500, color: '#374151', marginBottom: 12}}>Select your rating</p>
                                    <div style={{display: 'flex', gap: 4, marginBottom: 8}}>
                                        {[1,2,3,4,5].map(star => (
                                            <button key={star} type="button"
                                                    className="star-btn"
                                                    onClick={() => setSelectedRating(star)}
                                                    onMouseEnter={() => handleStarHover(star)}
                                                    onMouseLeave={() => setHoveredRating(0)}
                                                    style={{color: star <= activeRating ? '#f97316' : '#d1d5db'}}
                                            >
                                                {star <= activeRating ? '★' : '☆'}
                                            </button>
                                        ))}
                                    </div>

                                    {activeRating > 0 && (
                                        <div className="star-display">
                                            <p>Star Rating API response:</p>
                                            <div className="stars">{starDisplay || '...'}</div>
                                            <p style={{fontSize: 12, color: '#9ca3af', marginTop: 4}}>Rating: {activeRating} / 5</p>
                                        </div>
                                    )}

                                    <button type="submit" className="btn-primary" disabled={submitting || selectedRating === 0}
                                            style={{width: '100%', marginTop: 20}}>
                                        {submitting ? 'Submitting...' : 'Submit Review'}
                                    </button>
                                </form>
                            </div>

                            {/* Overall Rating */}
                            {reviews.length > 0 && (
                                <div className="card">
                                    <h3 style={{fontSize: 18, fontWeight: 700, marginBottom: 20}}>Overall Rating</h3>
                                    <div className="overall-rating">
                                        <div className="overall-number">{avgRating}</div>
                                        <div className="overall-stars">
                                            {[1,2,3,4,5].map(s => (
                                                <span key={s} style={{color: s <= Math.round(avgRating) ? '#f97316' : '#e5e7eb'}}>★</span>
                                            ))}
                                        </div>
                                        <div className="overall-count">{reviews.length} review{reviews.length !== 1 ? 's' : ''}</div>
                                    </div>
                                    {starCounts.map(({ star, count, percent }) => (
                                        <div key={star} className="rating-bar">
                                            <span style={{fontSize: 13, color: '#6b7280', width: 12}}>{star}</span>
                                            <span style={{color: '#f97316', fontSize: 13}}>★</span>
                                            <div className="rating-bar-fill">
                                                <div className="rating-bar-inner" style={{width: `${percent}%`}} />
                                            </div>
                                            <span style={{fontSize: 12, color: '#9ca3af', width: 16}}>{count}</span>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>

                        {/* Right — All Reviews */}
                        <div>
                            <div style={{display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 20}}>
                                <h3 style={{fontSize: 22, fontWeight: 700}}>
                                    All Reviews{' '}
                                    <span style={{background: '#fff7ed', color: '#f97316', fontSize: 13, fontWeight: 600, padding: '2px 12px', borderRadius: 999, marginLeft: 6}}>
                                        {reviews.length}
                                    </span>
                                </h3>
                                <button className="refresh-btn" onClick={fetchReviews}>↻ Refresh</button>
                            </div>

                            {loading ? (
                                <div className="spinner"><div className="spin" /></div>
                            ) : reviews.length === 0 ? (
                                <div className="empty">
                                    <div className="empty-icon">⭐</div>
                                    <h3>No reviews yet</h3>
                                    <p>Be the first to leave a review!</p>
                                </div>
                            ) : (
                                <div className="grid-2">
                                    {reviews.map((review, i) => (
                                        <div key={i} className="review-card">
                                            <div className="reviewer-info">
                                                <div className="avatar">{AVATARS[i % 8]}</div>
                                                <div>
                                                    <div className="reviewer-name">{NAMES[i % 8]}</div>
                                                    <div className="reviewer-tag">Verified Traveller</div>
                                                </div>
                                            </div>
                                            <div style={{display:'flex', gap: 2, marginBottom: 10}}>
                                                {[1,2,3,4,5].map(s => (
                                                    <span key={s} style={{fontSize: 18, color: s <= review.rating ? '#f97316' : '#e5e7eb'}}>★</span>
                                                ))}
                                                <span style={{fontSize: 13, color: '#9ca3af', marginLeft: 6}}>{review.rating}/5</span>
                                            </div>
                                            <p style={{fontSize: 14, color: '#6b7280', lineHeight: 1.6}}>{COMMENTS[i % 8]}</p>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            </div>

            <footer>
                <div className="container">
                    <div className="footer-grid">
                        <div>
                            <div className="footer-brand">TravelUs</div>
                            <p className="footer-text">Your journey, your way. Personalised travel experiences.</p>
                        </div>
                        <div>
                            <div className="footer-title">Quick Links</div>
                            <ul className="footer-links">
                                <li onClick={() => window.location.href='http://localhost:5173'}>Home</li>
                                <li onClick={() => window.location.href='http://localhost:3000'}>Packages</li>
                                <li onClick={() => window.location.href='http://localhost:3001/admin'}>Admin Dashboard</li>
                            </ul>
                        </div>
                        <div>
                            <div className="footer-title">Contact</div>
                            <ul className="footer-links">
                                <li>📧 support@travelus.com</li>
                                <li>📞 +94 76 944 5205</li>
                                <li>📍 Colombo, Sri Lanka</li>
                            </ul>
                        </div>
                    </div>
                    <div className="footer-bottom">© 2025 TravelUs — Review Module. All rights reserved.</div>
                </div>
            </footer>
        </div>
    )
}