import { useState, useEffect } from 'react'
import NavBar from '../Components/NavBar'
import { getAdminStats, getSystemOverview, getAllReviews } from '../Services/reviewService'

export default function AdminPage() {
    const [stats,    setStats]    = useState(null)
    const [overview, setOverview] = useState(null)
    const [reviews,  setReviews]  = useState([])
    const [loading,  setLoading]  = useState(true)
    const [error,    setError]    = useState('')

    useEffect(() => { fetchAll() }, [])

    const fetchAll = async () => {
        setLoading(true); setError('')
        try {
            const [s, o, r] = await Promise.all([getAdminStats(), getSystemOverview(), getAllReviews()])
            setStats(s); setOverview(o); setReviews(r)
        } catch {
            setError('Cannot connect to backend. Make sure Spring Boot is running on port 8082.')
        } finally { setLoading(false) }
    }

    const avgRating = reviews.length > 0
        ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1)
        : 0

    return (
        <div>
            <div className="admin-header">
                <NavBar />
                <h1>Admin Dashboard</h1>
                <p>Review Module — System Overview & Stats</p>
            </div>

            <div className="section">
                <div className="container">
                    {error && <div className="alert-error">⚠ {error}</div>}

                    {loading ? (
                        <div className="spinner"><div className="spin" /></div>
                    ) : (
                        <>
                            {/* Admin Stats */}
                            <div className="mb-10">
                                <div className="section-label">📊 Admin Statistics</div>
                                <div className="section-source">from /api/admin/stats</div>
                                <div className="grid-3">
                                    <StatCard icon="👥" label="Total Users"       value={stats?.totalUsers?.toLocaleString() || '—'} color="#2563eb" />
                                    <StatCard icon="💰" label="Total Revenue"     value={stats ? `$${stats.totalRevenue?.toLocaleString()}` : '—'} color="#16a34a" />
                                    <StatCard icon="⏳" label="Pending Reviews"   value={stats?.totalPendingReviews || '—'} color="#f97316" />
                                </div>
                            </div>

                            {/* System Overview */}
                            <div className="mb-10">
                                <div className="section-label">🖥 System Overview</div>
                                <div className="section-source">from /api/system/overview</div>
                                <div className="grid-3">
                                    <StatCard icon="👤" label="System Users"    value={overview?.totalUsers?.toLocaleString() || '—'} color="#7c3aed" />
                                    <StatCard icon="💵" label="System Revenue"  value={overview?.totalRevenue || '—'} color="#0d9488" />
                                    <StatCard icon="✅" label="Active Reviews"  value={overview?.activeReviews || '—'} color="#db2777" />
                                </div>
                            </div>

                            {/* Live Reviews */}
                            <div>
                                <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom: 24}}>
                                    <div>
                                        <div className="section-label">
                                            ⭐ Live Reviews{' '}
                                            <span style={{background:'#fff7ed', color:'#f97316', fontSize:13, fontWeight:600, padding:'2px 12px', borderRadius:999, marginLeft:6}}>
                                                {reviews.length}
                                            </span>
                                        </div>
                                        <div className="section-source">from /api/reviews</div>
                                    </div>
                                    <div style={{display:'flex', alignItems:'center', gap:12}}>
                                        {reviews.length > 0 && (
                                            <div className="stat-card" style={{padding:'10px 20px', textAlign:'center'}}>
                                                <div style={{fontSize:12, color:'#9ca3af'}}>Average</div>
                                                <div style={{fontSize:22, fontWeight:700, color:'#f97316'}}>{avgRating} ★</div>
                                            </div>
                                        )}
                                        <button className="refresh-btn" onClick={fetchAll}>↻ Refresh</button>
                                    </div>
                                </div>

                                {reviews.length === 0 ? (
                                    <div className="empty">
                                        <div className="empty-icon">📭</div>
                                        <h3>No reviews yet</h3>
                                        <p>Reviews submitted on the main page appear here.</p>
                                        <button className="btn-primary" onClick={() => window.location.href='http://localhost:3001'}>
                                            Go to Review Page
                                        </button>
                                    </div>
                                ) : (
                                    <div className="card" style={{padding:0, overflow:'hidden'}}>
                                        <table>
                                            <thead>
                                            <tr>
                                                <th>#</th>
                                                <th>Stars</th>
                                                <th>Display</th>
                                                <th>Score</th>
                                            </tr>
                                            </thead>
                                            <tbody>
                                            {reviews.map((review, i) => (
                                                <tr key={i}>
                                                    <td style={{color:'#9ca3af'}}>{i+1}</td>
                                                    <td>
                                                        <div style={{display:'flex', gap:2}}>
                                                            {[1,2,3,4,5].map(s => (
                                                                <span key={s} style={{fontSize:18, color: s<=review.rating ? '#f97316':'#e5e7eb'}}>★</span>
                                                            ))}
                                                        </div>
                                                    </td>
                                                    <td style={{fontFamily:'monospace', fontSize:13, color:'#f97316'}}>
                                                        {'★'.repeat(review.rating)+'☆'.repeat(5-review.rating)}
                                                    </td>
                                                    <td>
                                                            <span className={`badge ${review.rating>=4?'badge-green':review.rating===3?'badge-yellow':'badge-red'}`}>
                                                                {review.rating}/5
                                                            </span>
                                                    </td>
                                                </tr>
                                            ))}
                                            </tbody>
                                        </table>
                                    </div>
                                )}
                            </div>
                        </>
                    )}
                </div>
            </div>

            <footer>
                <div className="container">
                    <div className="footer-bottom">
                        <div className="footer-brand" style={{marginBottom:8}}>TravelUs</div>
                        © 2025 TravelUs — Review Module Admin
                    </div>
                </div>
            </footer>
        </div>
    )
}

function StatCard({ icon, label, value, color }) {
    return (
        <div className="stat-card">
            <div className="stat-icon">{icon}</div>
            <div className="stat-label">{label}</div>
            <div className="stat-value" style={{color}}>{value}</div>
        </div>
    )
}