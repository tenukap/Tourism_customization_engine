// Review Module API Service
// Default backend: http://localhost:8082
// Optional override: create .env with VITE_API_BASE_URL=http://localhost:8082

const BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:8082').replace(/\/$/, '')

async function request(path, options = {}) {
    let res

    try {
        res = await fetch(`${BASE_URL}${path}`, {
            headers: { 'Content-Type': 'application/json', ...(options.headers || {}) },
            ...options
        })
    } catch {
        throw new Error(`Cannot connect to backend at ${BASE_URL}`)
    }

    if (!res.ok) {
        const message = await res.text().catch(() => '')
        throw new Error(message || `Request failed: ${res.status}`)
    }

    if (res.status === 204) return null
    return res.json()
}

// GET /api/health — check backend connection
export function checkBackendHealth() {
    return request('/api/health')
}

// POST /api/reviews — submit a new review
export function submitReview(rating) {
    return request('/api/reviews', {
        method: 'POST',
        body: JSON.stringify({ rating })
    })
}

// GET /api/reviews — get all reviews
export function getAllReviews() {
    return request('/api/reviews')
}

// GET /api/stars?rating=4 — get star display for a rating
export function getStarRating(rating) {
    return request(`/api/stars?rating=${rating}`)
}

// GET /api/admin/stats — get dashboard stats
export function getAdminStats() {
    return request('/api/admin/stats')
}

// GET /api/system/overview — get system overview
export function getSystemOverview() {
    return request('/api/system/overview')
}
