package com.tourapp.reviews.model;

public class SystemOverview {

    private int totalUsers;
    private String totalRevenue;
    private int activeReviews;

    public SystemOverview() {
    }

    public SystemOverview(int totalUsers, String totalRevenue, int activeReviews) {
        this.totalUsers = totalUsers;
        this.totalRevenue = totalRevenue;
        this.activeReviews = activeReviews;
    }

    public int getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(int totalUsers) {
        this.totalUsers = totalUsers;
    }

    public String getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(String totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public int getActiveReviews() {
        return activeReviews;
    }

    public void setActiveReviews(int activeReviews) {
        this.activeReviews = activeReviews;
    }
}
