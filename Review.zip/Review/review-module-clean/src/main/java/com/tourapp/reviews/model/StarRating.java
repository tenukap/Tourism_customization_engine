package com.tourapp.reviews.model;

public class StarRating {

    private int rating;
    private String stars;

    public StarRating() {
    }

    public StarRating(int rating, String stars) {
        this.rating = rating;
        this.stars = stars;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getStars() {
        return stars;
    }

    public void setStars(String stars) {
        this.stars = stars;
    }
}
