package com.tourapp.reviews.model;

public class AdminStats {

    private Long totalUsers;
    private Double totalRevenue;
    private Long totalPendingReviews;

    public AdminStats() {
    }

    public AdminStats(Long totalUsers, Double totalRevenue, Long totalPendingReviews) {
        this.totalUsers = totalUsers;
        this.totalRevenue = totalRevenue;
        this.totalPendingReviews = totalPendingReviews;
    }

    public Long getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(Long totalUsers) {
        this.totalUsers = totalUsers;
    }

    public Double getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(Double totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public Long getTotalPendingReviews() {
        return totalPendingReviews;
    }

    public void setTotalPendingReviews(Long totalPendingReviews) {
        this.totalPendingReviews = totalPendingReviews;
    }
}
