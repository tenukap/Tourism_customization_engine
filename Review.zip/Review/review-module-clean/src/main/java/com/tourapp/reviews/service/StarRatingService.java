package com.tourapp.reviews.service;

import com.tourapp.reviews.model.StarRating;
import org.springframework.stereotype.Service;

@Service
public class StarRatingService {

    public StarRating getStarRating(int rating) {
        validateRating(rating);

        StringBuilder stars = new StringBuilder();
        for (int i = 0; i < 5; i++) {
            if (i < rating) {
                stars.append("★ ");
            } else {
                stars.append("☆ ");
            }
        }

        return new StarRating(rating, stars.toString().trim());
    }

    private void validateRating(int rating) {
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5");
        }
    }
}
