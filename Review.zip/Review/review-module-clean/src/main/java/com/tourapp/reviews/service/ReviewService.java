package com.tourapp.reviews.service;

import com.tourapp.reviews.model.Review;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class ReviewService {

    private final List<Review> reviews = new ArrayList<>();

    public Review saveReview(Review review) {
        validateRating(review.getRating());
        reviews.add(review);
        return review;
    }

    public List<Review> getAllReviews() {
        return new ArrayList<>(reviews);
    }

    private void validateRating(int rating) {
        if (rating < 1 || rating > 5) {
            throw new IllegalArgumentException("Rating must be between 1 and 5");
        }
    }
}
