package com.tourapp.reviews.model;

public class Review {

    private int rating;

    public Review() {
    }

    public Review(int rating) {
        this.rating = rating;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }
}
