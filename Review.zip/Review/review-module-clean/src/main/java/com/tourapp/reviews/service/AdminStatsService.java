package com.tourapp.reviews.service;

import com.tourapp.reviews.model.AdminStats;
import org.springframework.stereotype.Service;

@Service
public class AdminStatsService {

    public Long getTotalUsers() {
        return 1250L;
    }

    public Double getTotalRevenue() {
        return 45900.75;
    }

    public Long getTotalPendingReviews() {
        return 15L;
    }

    public AdminStats getDashboardStats() {
        return new AdminStats(
                getTotalUsers(),
                getTotalRevenue(),
                getTotalPendingReviews()
        );
    }
}
