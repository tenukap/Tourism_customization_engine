package com.tourapp.reviews.service;

import com.tourapp.reviews.model.SystemOverview;
import org.springframework.stereotype.Service;

@Service
public class SystemOverviewService {

    public SystemOverview getSystemOverview() {
        int totalUsers = 1250;
        String totalRevenue = "$45,000";
        int activeReviews = 89;

        return new SystemOverview(totalUsers, totalRevenue, activeReviews);
    }
}
