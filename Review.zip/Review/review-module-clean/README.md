# Review Module - Clean Structure

This zip reorganizes the review-related Java files into a clean Spring Boot module structure.

## Structure

```text
review-module
├── pom.xml
└── src
    └── main
        ├── java
        │   └── com
        │       └── tourapp
        │           └── reviews
        │               ├── ReviewModuleApplication.java
        │               ├── config
        │               │   └── CorsConfig.java
        │               ├── controller
        │               │   ├── AdminStatsController.java
        │               │   ├── ReviewController.java
        │               │   ├── StarRatingController.java
        │               │   └── SystemOverviewController.java
        │               ├── model
        │               │   ├── AdminStats.java
        │               │   ├── Review.java
        │               │   ├── StarRating.java
        │               │   └── SystemOverview.java
        │               └── service
        │                   ├── AdminStatsService.java
        │                   ├── ReviewService.java
        │                   ├── StarRatingService.java
        │                   └── SystemOverviewService.java
        └── resources
            └── application.properties
```

## Run

```bash
cd review-module
mvn spring-boot:run
```

Default port: `8082`

## Endpoints

- `GET /api/reviews`
- `POST /api/reviews`
- `GET /api/stars?rating=5`
- `GET /api/admin/stats`
- `GET /api/system/overview`

